from .analyzer import MorphAnalyzer
from .version import __version__
