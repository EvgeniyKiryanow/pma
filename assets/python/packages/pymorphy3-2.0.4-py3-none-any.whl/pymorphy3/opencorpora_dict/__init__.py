from .compile import convert_to_pymorphy2
from .storage import load_dict as load
from .wrapper import Dictionary
