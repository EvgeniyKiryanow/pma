Contributors
============
Original author
---------------
* Mikhail Korobov (`@kmike <https://github.com/kmike>`_)

Maintainers
-----------
* Danylo Halaiko (`@d9nchik <https://github.com/d9nchik>`_)
* `@insolor <https://github.com/insolor>`_

Contributors
------------
* Andrej (`@Andrej730 <https://github.com/Andrej730>`_)
* Denis Bezykornov (`@ArchiDevil <https://github.com/ArchiDevil>`_)
* `@BLKSerene <https://github.com/BLKSerene>`_
* Illia Fedorovych (`@Kowalski0805 <https://github.com/Kowalski0805>`_)
* Hannes Krumbiegel (`@Vuizur <https://github.com/Vuizur>`_)
* `@valentino-sm <https://github.com/valentino-sm>`_

If you have contributed to pymorphy3, please add yourself to this list (or update your contact information).

For a list of contributors to pymorphy2 (predecessor of pymorphy3), please see: https://github.com/pymorphy2/pymorphy2 
